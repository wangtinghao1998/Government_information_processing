import psycopg2
import base64


def base64_decode(base64EncodedData):
    if not base64EncodedData:
        return base64EncodedData

    decoded_data = base64.b64decode(base64EncodedData)
    return decoded_data.decode('utf-8')


def postgres_connect():
    """
        base64EncodedData：处理文件（base64加密后的hash值）
        updateStatus：需要更正的状态值
    """
    # 连接参数
    db_host = '60.205.217.212'
    db_port = '8022'
    db_name = 'postgres'
    db_user = 'postgres'
    db_password = '2ws3ed@WS#ED'
    # 建立连接
    conn = psycopg2.connect(host=db_host, port=db_port, dbname=db_name, user=db_user, password=db_password)
    # 创建游标对象
    cur = conn.cursor()
    """
        在PostgreSQL中，如果创建表名时使用了双引号将表名括起来，则表名就成为了区分大小写的标识符
        那么在查询时也需要使用相同的大小写形式，即"SELECT ... FROM "GFile" WHERE ..."，否则会报错。字段也是同样道理
    """
    hashValue = base64_decode("Yk5iTStGNmg4cW11Sk5EdlZoY1VnZz09")
    print(f"转换后的hash值\t{hashValue}")
    cur.execute('SELECT "BatchID" FROM "GFile" WHERE "Hash" = %s', (hashValue,))
    result = cur.fetchone()
    print(str(result[0]))
    # cur.execute('UPDATE "GFile" SET "Status" = %s WHERE "Hash" = %s', (updateStatus, hashValue))
    # # 提交更改
    # conn.commit()

    # cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='public'")  # 执行查询
    # tables = cur.fetchall()# 获取所有表名
    # for table in tables:# 输出数据库中所有表名
    #     print(table[0])

    # 关闭游标和连接
    cur.close()
    conn.close()


if __name__ == '__main__':
    # 测试下流程
    postgres_connect()
