from transformers import BertTokenizerFast, BertForTokenClassification
from transformers import pipeline
import docx
import os

"""
    处理 docx 文件
"""
violation_text = ["财政奖励", "补贴", "税收优惠", "土地", "劳动力", "资本", "技术"]
cannot_exist_text = "根据"
# 可能违规的句子，使用set去重
violation_para_text = set()
input_path = '批次1'
ner_entity = []


def verify_text(ner_text, para_text):
    # print(f"命名实体：{ner_text} \t\t\t 对应文本的句子{para_text}")
    for text in violation_text:
        # 如果这段话存在命名实体和违规文本，并且不包含"根据"两个字，则表示违规
        if ner_text in para_text and text in para_text and cannot_exist_text not in para_text:
            return para_text


def get_ner(input_entity, input_word):
    if input_entity.startswith('B'):
        ner_entity.clear()
        ner_entity.append(input_word)
    elif input_entity.startswith('I'):
        ner_entity.append(input_word)
    elif input_entity.startswith('E'):
        ner_entity.append(input_word)
        return str(''.join(ner_entity))


def get_all_file_path(path):
    if os.path.isdir(path):
        for file in os.listdir(path):
            file_path = os.path.join(path, file)
            if os.path.isfile(file_path):
                yield file_path
            else:
                yield from get_all_file_path(file_path)
    else:
        yield path


if __name__ == '__main__':
    tokenizer = BertTokenizerFast.from_pretrained('bert-base-chinese')
    model = BertForTokenClassification.from_pretrained('ckiplab/bert-base-chinese-ner')
    ner_pipe = pipeline('ner', model=model, tokenizer=tokenizer)

    for p in get_all_file_path(input_path):
        print(f'\n\n\n文件路径 {p},\n')
        # 获取文档对象
        docx_file = docx.Document(p)
        for paragraph in docx_file.paragraphs:
            para = paragraph.text
            for entity in ner_pipe(para):
                # 拿到处理完成的 entity【B-ORG、I-ORG、E-ORG】和 index
                deal_ner = get_ner(entity["entity"], entity["word"])
                if deal_ner:  # 找到了命名实体
                    if verify_text(deal_ner, para):
                        violation_para_text.add(para)
        for v in violation_para_text:
            print(f"{p}\t\t可能违规的文本:【{v}】")
    print('=' * 100)