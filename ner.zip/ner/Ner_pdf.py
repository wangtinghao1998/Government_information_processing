from transformers import BertTokenizerFast, BertForTokenClassification
from transformers import pipeline
import fitz
import os

"""
    处理 pdf 
"""
violation_text_list = ["财政奖励", "补贴", "税收优惠", "土地", "劳动力", "资本", "技术"]
cannot_exist_text = "根据"
input_path = '批次2'
ner_entity = []

def check_violation_text(ner_text, para_text):
    """
        将命名实体和所在段落传进来进行违规词检查，如果违规则输出该段落文本
        ner_text：命名实体
        para_text：实体对应的句子段
    """
    # print(f"命名实体：{ner_text} \t\t\t 对应文本的句子{para_text}")
    for violation_text in violation_text_list:
        # 如果这段话存在命名实体和违规文本，并且不包含"根据"两个字，则表示违规
        if ner_text in para_text and violation_text in para_text and cannot_exist_text not in para_text:
            return para_text

def get_ner(entity_tag, entity_word):
    """
        根据实体tag对命名实体进行拼接
        注：如果是BI结构，这里会有问题，待处理
    """
    if entity_tag.startswith('B'):
        ner_entity.clear()
        ner_entity.append(entity_word)
    elif entity_tag.startswith('I'):
        ner_entity.append(entity_word)
    elif entity_tag.startswith('E'):
        ner_entity.append(entity_word)
        return str(''.join(ner_entity))

def get_all_file_path(path):
    """
        检查path路径，遍历找到文件
    """
    if os.path.isdir(path):
        for file in os.listdir(path):
            file_path = os.path.join(path, file)
            if os.path.isfile(file_path):
                yield file_path
            else:
                yield from get_all_file_path(file_path)
    else:
        yield path


if __name__ == '__main__':
    tokenizer = BertTokenizerFast.from_pretrained('bert-base-chinese')
    model = BertForTokenClassification.from_pretrained('ckiplab/bert-base-chinese-ner')
    ner_pipe = pipeline('ner', model=model, tokenizer=tokenizer)

    for path in get_all_file_path(input_path):
        print(f'\n\n\n正在检查： {path}')
        print('=' * 100)
        # 打开 PDF 文件
        pdf_file = fitz.open(path)
        # 获取 PDF 页面数量
        num_pages = pdf_file.page_count
        # 循环遍历每一页
        for page_idx in range(num_pages):
            # 获取当前页
            page_obj = pdf_file[page_idx]  # page 0 of /Users/wangtinghao/Desktop/example.pdf
            # 提取页文本内容
            page_text = page_obj.get_text()
            # 提取段文本内容
            para_text_list = page_text.split('。')
            text_list = []
            # 提取每一行文本
            for para_text in para_text_list:
                for entity in ner_pipe(para_text):
                    # 拿到处理完成的 entity【B-ORG、I-ORG、E-ORG】和 index
                    ner_text = get_ner(entity["entity"], entity["word"])
                    if ner_text:  # 找到了命名实体
                        violation_text = check_violation_text(ner_text, para_text)
                        if violation_text:
                            text_list.append(violation_text)
            for text in set(text_list):
                print(f"{path} : 可能违规的文本:【{text}】")
                print('*' * 100)
        # 关闭 PDF 文件
        pdf_file.close()
