import paramiko
import os


def connect(process_pdf_file):
    """
        1. 连接到远程服务器，访问服务器/dgcr/docker/dgcr-api/data/process/processing下的所有文件
        2. 对这些文件进行pdf处理（命名实体识别）
            在这个示例中，我们将文件下载到本地计算机上是因为我们需要对文件进行处理，而本地计算机通常拥有更高的计算能力和更方便的程序开发环境。
            如果直接在远程服务器上执行该处理过程，可能会受限于服务器处理能力和配置，此外还需要在服务器上安装必要的软件和库以支持相关功能。
            因此，为了提高处理效率和方便开发，我们首先将文件下载到本地计算机上进行处理，然后将处理结果上传回远程服务器。
            当然，在实际应用中，如果您的服务器足够强大并且您有足够的权限来在服务器上安装必要的软件和库，您也可以在服务器上进行处理。
    """
    hostname = "60.205.217.212"
    port = 22
    username = "root"
    password = "Cnu@105xg+-"
    # SFTP连接参数
    remote_input_dir = '/dgcr/docker/dgcr-api/data/process/esoutput'
    remote_output_dir = '/dgcr/docker/dgcr-api/data/process/bertoutput2'
    local_dir = os.path.expanduser("~/Desktop")
    # 建立SSH连接
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=hostname, port=port, username=username, password=password)
    # 建立SFTP连接
    sftp = ssh.open_sftp()
    sftp.chdir(remote_input_dir)
    # 下载文件
    files = sftp.listdir()
    for file in files:
        remote_file = os.path.join(remote_input_dir, file)
        local_file = os.path.join(local_dir, file)
        sftp.get(remote_file, local_file)
        result = process_pdf_file(local_file)
        print(f"当前处理的是{file},结果是{result}")
        output_file = os.path.join(remote_output_dir, file)
        # 遍历违规列表
        if result:
            with sftp.open(output_file, 'w') as f:
                for i in result:
                    f.write(i)
    # 关闭连接
    sftp.close()
    ssh.close()
