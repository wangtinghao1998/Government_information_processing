from transformers import BertTokenizerFast, BertForTokenClassification
from transformers import pipeline
import psycopg2
import base64
import fitz
import paramiko
import os

ner_entity = []

def base64_decode(base64EncodedData):
    if not base64EncodedData:
        return base64EncodedData

    decoded_data = base64.b64decode(base64EncodedData)
    return decoded_data.decode('utf-8')


def get_ner(entity_tag, entity_word):
    """
        根据实体tag对命名实体进行拼接
        注：如果是BI结构，这里会有问题，待处理
    """
    if entity_tag.startswith('B'):
        ner_entity.clear()
        ner_entity.append(entity_word)
    elif entity_tag.startswith('I'):
        ner_entity.append(entity_word)
    elif entity_tag.startswith('E'):
        ner_entity.append(entity_word)
        return str(''.join(ner_entity))


def process_pdf_file(input_file_path):
    print(f'\n\n\n正在检查： {input_file_path}')
    print('=' * 100)
    if input_file_path.endswith(".txt"):
        return None
    else:
        # 创建一个数组，用于存放违规且标黄
        violate_list = []
        # 打开 PDF 文件
        pdf_file = fitz.open(input_file_path)
        # 获取 PDF 页面数量
        num_pages = pdf_file.page_count
        # 循环遍历每一页
        for page_idx in range(num_pages):
            # 获取当前页
            page_obj = pdf_file[page_idx]  # page 0 of /Users/wangtinghao/Desktop/example.pdf
            # 获取页面的宽和高
            page_width = round(page_obj.rect.width, 2)
            page_height = round(page_obj.rect.height, 2)
            # 提取页文本内容
            page_text = page_obj.get_text()
            # 提取段文本内容
            para_text_list = page_text.split('。')
            # 提取每一行文本
            for para_text in para_text_list:
                for entity in ner_pipe(para_text):
                    # 拿到处理完成的 entity【B-ORG、I-ORG、E-ORG】和 index
                    ner_text = get_ner(entity["entity"], entity["word"])
                    if ner_text:  # 找到了命名实体
                        print(f"当前查找到的命名实体为\t 【{ner_text}】")
                        # 在页面中查找目标文本
                        matches = page_obj.search_for(ner_text)
                        # 遍历每个匹配项，对需要高亮的部分进行封装，只保留两位小数
                        for match in matches:
                            x = left = round(match[0], 2)
                            y = top = page_height - round(match[1], 2)
                            right = round(match[2], 2)
                            bottom = page_height - round(match[3], 2)
                            width = round(right - left, 2)
                            height = round(bottom - top, 2)
                            size = (f"{width},{height}")
                            requestDir = {"Page": page_idx,
                                          "Bounds": {"Location": {"IsEmpty": 0, "X": x, "Y": y}, "Size": size,
                                                     "X": x, "Y": y, "Width": width, "Height": height, "Left": left,
                                                     "Top": top, "Right": right, "Bottom": bottom, "IsEmpty": 1},
                                          "Comment": ner_text, "Description": ner_text}
                            violate_list.append(requestDir)
        # 关闭 PDF 文件
        pdf_file.close()
        return violate_list


def sftp_ssh_database_connect_and_update_file_status(updateStatus):
    # 数据库参数
    db_host = '60.205.217.212'
    db_port = '8022'
    db_name = 'postgres'
    db_user = 'postgres'
    db_password = '2ws3ed@WS#ED'
    # 建立连接
    conn = psycopg2.connect(host=db_host, port=db_port, dbname=db_name, user=db_user, password=db_password)
    # 创建游标对象
    cur = conn.cursor()

    # 服务器参数
    hostname = "60.205.217.212"
    port = 22
    username = "root"
    password = "Cnu@105xg+-"
    # 建立SSH连接
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=hostname, port=port, username=username, password=password)
    # 建立SFTP连接
    sftp = ssh.open_sftp()
    # SFTP连接参数
    remote_dir = '/dgcr/docker/dgcr-api/data/process/test'
    local_input_dir = os.path.expanduser("~/Desktop/test")
    sftp.chdir(remote_dir)
    # 下载文件
    files = sftp.listdir()
    for file in files:
        remote_file = os.path.join(remote_dir, file)
        local_file = os.path.join(local_input_dir, file)
        """
            我们将文件下载到本地计算机上是因为我们需要对文件进行处理，而本地计算机通常拥有更高的计算能力和更方便的程序开发环境。
            如果直接在远程服务器上执行该处理过程，可能会受限于服务器处理能力和配置，此外还需要在服务器上安装必要的软件和库以支持相关功能。
            当然，在实际应用中，如果您的服务器足够强大并且您有足够的权限来在服务器上安装必要的软件和库，您也可以在服务器上进行处理。
        """
        # 从服务器将文件下载到本地
        sftp.get(remote_file, local_file)
        # 使用PyMuPDF工具处理这些文件
        violate_list = process_pdf_file(local_file)
        if violate_list:
            """
                    在PostgreSQL中，如果创建表名时使用了双引号将表名括起来，则表名就成为了区分大小写的标识符
                    那么在查询时也需要使用相同的大小写形式，即"SELECT ... FROM "GFile" WHERE ..."，否则会报错。字段也是同样道理
            """
            print(f"处理完成后，文件的违规值列表为\t{str(violate_list[:3])}")
            print(f"当前处理的hash值\t{file}")
            hashValue = base64_decode(file)
            print(f"转换后的hash值\t{hashValue}")
            cur.execute('SELECT "BatchID" FROM "GFile" WHERE "Hash" = %s', (hashValue,))
            batchID = cur.fetchone()
            remote_output_file = os.path.join(remote_dir, str(batchID[0]), file)
            print(f"当前处理的文件是\t{remote_output_file}")

            # 更改文件状态为updateStatus，这里写成2代表是待分配
            cur.execute('UPDATE "GFile" SET "Status" = %s WHERE "Hash" = %s', (updateStatus, hashValue))
            cur.execute('UPDATE "GFile" SET "AuditAnnotations" = %s WHERE "Hash" = %s',
                        (str(violate_list), hashValue))
            # 提交更改
            conn.commit()

    # 关闭游标和连接
    cur.close()
    conn.close()
    # 关闭连接
    sftp.close()
    ssh.close()


if __name__ == '__main__':
    tokenizer = BertTokenizerFast.from_pretrained('bert-base-chinese')
    model = BertForTokenClassification.from_pretrained('ckiplab/bert-base-chinese-ner')
    ner_pipe = pipeline('ner', model=model, tokenizer=tokenizer)
    # 文件状态设置为待分配
    sftp_ssh_database_connect_and_update_file_status(2)
