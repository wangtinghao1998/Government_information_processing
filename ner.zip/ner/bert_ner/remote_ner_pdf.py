from transformers import BertTokenizerFast, BertForTokenClassification
from transformers import pipeline
import psycopg2
import base64
import fitz
import paramiko
import os

ner_entity = []


def base64_decode(base64EncodedData):
    if not base64EncodedData:
        return base64EncodedData

    decoded_data = base64.b64decode(base64EncodedData)
    return decoded_data.decode('utf-8')


def get_ner(entity_tag, entity_word):
    """
        根据实体tag对命名实体进行拼接
        注：如果是BI结构，这里会有问题，待处理
    """
    if entity_tag.startswith('B'):
        ner_entity.clear()
        ner_entity.append(entity_word)
    elif entity_tag.startswith('I'):
        ner_entity.append(entity_word)
    elif entity_tag.startswith('E'):
        ner_entity.append(entity_word)
        return str(''.join(ner_entity))


def process_pdf_file(input_path, output_path):
    print(f'\n\n\n正在检查： {input_path}')
    print('=' * 100)
    if input_path.endswith(".txt"):
        return False
    else:
        # 打开 PDF 文件
        pdf_file = fitz.open(input_path)
        # 获取 PDF 页面数量
        num_pages = pdf_file.page_count
        # 循环遍历每一页
        for page_idx in range(num_pages):
            # 获取当前页
            page_obj = pdf_file[page_idx]  # page 0 of /Users/wangtinghao/Desktop/example.pdf
            # 提取页文本内容
            page_text = page_obj.get_text()
            # 提取段文本内容
            para_text_list = page_text.split('。')
            # 提取每一行文本
            for para_text in para_text_list:
                for entity in ner_pipe(para_text):
                    # 拿到处理完成的 entity【B-ORG、I-ORG、E-ORG】和 index
                    ner_text = get_ner(entity["entity"], entity["word"])
                    if ner_text:  # 找到了命名实体
                        print(f"当前查找到的命名实体为\t 【{ner_text}】")
                        # 在页面中查找目标文本
                        matches = page_obj.search_for(ner_text)
                        # 遍历每个匹配项，并进行高亮
                        for match in matches:
                            highlight = page_obj.add_highlight_annot(match)
                            # 设置高亮颜色为黄色
                            highlight.update()
                            highlight.color = fitz.utils.getColor('yellow')

        pdf_file.save(output_path)
        # 关闭 PDF 文件
        pdf_file.close()
        return True


def sftp_ssh_database_connect_and_update_file_status(updateStatus):
    """
        1. 连接到远程服务器，访问服务器/dgcr/docker/dgcr-api/data/process/processing下的所有文件
        2. 对这些文件进行pdf处理（命名实体识别）
            在这个示例中，我们将文件下载到本地计算机上是因为我们需要对文件进行处理，而本地计算机通常拥有更高的计算能力和更方便的程序开发环境。
            如果直接在远程服务器上执行该处理过程，可能会受限于服务器处理能力和配置，此外还需要在服务器上安装必要的软件和库以支持相关功能。
            因此，为了提高处理效率和方便开发，我们首先将文件下载到本地计算机上进行处理，然后将处理结果上传回远程服务器。
            当然，在实际应用中，如果您的服务器足够强大并且您有足够的权限来在服务器上安装必要的软件和库，您也可以在服务器上进行处理。
        3. 连接数据库，对文件状态进行修改
        4. 关闭所有资源
    """
    # 连接参数
    db_host = '60.205.217.212'
    db_port = '8022'
    db_name = 'postgres'
    db_user = 'postgres'
    db_password = '2ws3ed@WS#ED'
    # 建立连接
    conn = psycopg2.connect(host=db_host, port=db_port, dbname=db_name, user=db_user, password=db_password)
    # 创建游标对象
    cur = conn.cursor()

    # 服务器参数
    hostname = "60.205.217.212"
    port = 22
    username = "root"
    password = "Cnu@105xg+-"
    # SFTP连接参数
    remote_input_dir = '/dgcr/docker/dgcr-api/data/process/test'
    remote_output_dir = '/dgcr/docker/dgcr-api/data/gfiles/'
    local_input_dir = os.path.expanduser("~/Desktop/progress")
    local_output_dir = os.path.expanduser("~/Desktop/complete")
    # 建立SSH连接
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(hostname=hostname, port=port, username=username, password=password)
    # 建立SFTP连接
    sftp = ssh.open_sftp()
    sftp.chdir(remote_input_dir)
    # 下载文件
    files = sftp.listdir()
    for file in files:
        remote_input_file = os.path.join(remote_input_dir, file)
        local_input_file = os.path.join(local_input_dir, file)
        local_output_file = os.path.join(local_output_dir, file)
        # 从服务器将文件下载到本地
        sftp.get(remote_input_file, local_input_file)
        # 使用PyMuPDF工具处理这些文件
        result = process_pdf_file(local_input_file, local_output_file)
        # 重新回传到服务器，处理完成的文件同时需要修改数据库状态
        if result:
            """
                在PostgreSQL中，如果创建表名时使用了双引号将表名括起来，则表名就成为了区分大小写的标识符
                那么在查询时也需要使用相同的大小写形式，即"SELECT ... FROM "GFile" WHERE ..."，否则会报错。字段也是同样道理
            """
            print(f"当前处理的hash值\t{str(file)}")
            hashValue = base64_decode(str(file))
            # 这里需要注意，传入的是需要是元组类型
            cur.execute('SELECT "BatchID" FROM "GFile" WHERE "Hash" = %s', (hashValue,))
            batchID = cur.fetchone()
            remote_output_file = os.path.join(remote_output_dir, str(batchID[0]), file)

            print(f"转换后的hash值\t{hashValue}")
            print(f"当前处理文件batchID为\t{str(batchID[0])}")
            print(f"重新上传到服务器，地址为\t{remote_output_file}")

            try:
                sftp.stat(remote_output_file)
                sftp.remove(remote_output_file)  # 若远程文件存在则删除
            except IOError:
                print("远程文件不存在，不执行删除操作（报错）")
                pass  # 远程文件不存在，不执行删除操作
            sftp.put(local_output_file, remote_output_file)  # 上传文件

            cur.execute('UPDATE "GFile" SET "Status" = %s WHERE "Hash" = %s', (updateStatus, hashValue))
            # 提交更改
            conn.commit()

    # 关闭游标和连接
    cur.close()
    conn.close()
    # 关闭连接
    sftp.close()
    ssh.close()


if __name__ == '__main__':
    tokenizer = BertTokenizerFast.from_pretrained('bert-base-chinese')
    model = BertForTokenClassification.from_pretrained('ckiplab/bert-base-chinese-ner')
    ner_pipe = pipeline('ner', model=model, tokenizer=tokenizer)
    # 文件状态设置为待分配
    sftp_ssh_database_connect_and_update_file_status(2)
