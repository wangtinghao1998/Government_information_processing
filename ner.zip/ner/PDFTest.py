import fitz

def search_and_highlight_word_in_pdf(pdf_file_path, word):
    doc = fitz.open(pdf_file_path)
    for page_num, page in enumerate(doc):
        text_instances = page.search_for(word)
        if len(text_instances) > 0:
            for inst in text_instances:
                print("x1: %s, y1: %s, x2: %s, y2: %s" % (inst.x0, inst.y0, inst.x1, inst.y1))

                highlight = page.add_highlight_annot(inst)
                highlight.update()
                print("在第%s页找到了该字，位置信息如下：" % (page_num + 1))
                print("x坐标：%s" % inst[0])
                print("y坐标：%s" % inst[1])
                print("宽度：%s" % inst[2])
                print("高度：%s" % inst[3])
                # highlight = page.add_highlight_annot(inst)
                # highlight.update()
                # print("在第%s页找到了该字，位置信息如下：" % (page_num + 1))
                # print("x坐标：%s" % inst[0])
                # print("y坐标：%s" % inst[1])
                # print("宽度：%s" % inst[2])
                # print("高度：%s" % inst[3])

        else:
            print("在第%s页没有找到该字" % (page_num + 1))
    doc.save(pdf_file_path[:-4] + "_highlighted.pdf")
    doc.close()


if __name__ == '__main__':
    search_and_highlight_word_in_pdf(
        "/Users/wangtinghao/DevFolder/code_nlp/ner/remote_yinshe/dgcr/docker/dgcr-api/data/gfiles/46/WFlDMG10eC93RnFoU1dFMGNkaG9Idz09",
        "小样本学习")
